create table Nurse (
	Nurse_id VARCHAR(20) primary key,
	NurseName VARCHAR(60),
	Hopital_id INT
);

insert into Nurse  values ('773-33-2575', 'Boone Sandwith', 6),
('260-69-7790', 'Gradeigh Wardley', 8),
('222-84-7511', 'Chen Treadger', 9),
('570-30-9878', 'Davita Inglesent', 2),
('630-62-2305', 'Irena Showte', 15),
('595-90-5316', 'Margret Noah', 19),
('363-78-6929', 'Cinda Peasnone', 6),
('708-06-9495', 'Carmella Siggin', 14),
('808-98-1564', 'Kassandra Ricca', 15),
('747-01-4776', 'Karilynn Fulham', 6),
('286-73-6050', 'Marve Trodler', 2);