CREATE TABLE Employee (
EmpID CHAR(5) PRIMARY KEY,
EmpName VARCHAR(30),
password VARCHAR(20),
start_date DATE);

INSERT INTO Employee VALUES ('E1983', 'John Doe', 'JDoe@123', '2020-04-01'), ('E1645', 'Irene Gradeigh', 'Ireneigh!1', '2018-06-01'), 
('E1027', 'Margaret Fulham', 'MargFulham#2', '2022-09-01'), ('E1402', 'Noah San', 'Sanoah&3', '2017-11-01');
